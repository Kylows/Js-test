import Pagination from './Pagination'
import PaginationItem from './PaginationItem'

export { Pagination, PaginationItem }
