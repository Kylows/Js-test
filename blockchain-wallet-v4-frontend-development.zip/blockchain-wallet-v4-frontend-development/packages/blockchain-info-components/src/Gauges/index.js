export { default as ConfirmationGauge } from './ConfirmationGauge'
export { default as PasswordGauge } from './PasswordGauge'
export { default as SecurityGauge } from './SecurityGauge'
