export { default as Badge } from './Badge'
