// an empty file suffices as a mock
