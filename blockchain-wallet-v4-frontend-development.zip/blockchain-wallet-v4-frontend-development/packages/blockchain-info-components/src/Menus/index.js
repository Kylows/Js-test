import TabMenu from './TabMenu/TabMenu'
import TabMenuItem from './TabMenu/TabMenuItem'

export { TabMenu, TabMenuItem }
