export { default as SimpleSlider } from './SimpleSlider'
