import SkeletonCircle from './SkeletonCircle'
import SkeletonRectangle from './SkeletonRectangle'

export { SkeletonCircle, SkeletonRectangle }
