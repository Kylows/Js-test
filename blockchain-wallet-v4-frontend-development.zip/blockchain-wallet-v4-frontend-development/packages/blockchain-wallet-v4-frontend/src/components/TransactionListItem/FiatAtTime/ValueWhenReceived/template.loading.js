import React from 'react'

import { FlatLoader } from 'blockchain-info-components'

export default props => <FlatLoader width='40px' height='10px' />
