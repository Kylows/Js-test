import { selectors } from 'data'

export const getData = selectors.core.data.misc.getCaptcha
