import * as AT from './actionTypes'

export const initialized = () => ({ type: AT.ETH_TRANSACTIONS_INITIALIZED })
