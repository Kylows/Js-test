import * as AT from './actionTypes'

export const initialized = () => ({ type: AT.ACTIVITY_LIST_INITIALIZED })
