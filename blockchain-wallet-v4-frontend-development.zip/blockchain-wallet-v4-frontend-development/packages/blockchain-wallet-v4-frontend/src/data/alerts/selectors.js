import { path } from 'ramda'

export const selectAlerts = path(['alerts'])
