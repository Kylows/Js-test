# Blockchain-Wallet-v4-Frontend

The frontend wallet application built with React/Redux.
