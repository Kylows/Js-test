module.exports = {
  ROOT_URL: 'https://testnet.blockchain.info',
  API_DOMAIN: 'https://api-testnet.blockchain.info',
  WEB_SOCKET_URL: 'wss://ws.blockchain.info/testnet3',
  WALLET_HELPER_DOMAIN: 'https://wallet-helper.blockchain.info',
  NETWORK_TYPE: 'testnet'
}
